const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate__fadeInLeft');
        } else {
            //entry.target.classList.remove('animate__fadeInLeft');
        }
    });
});

const animateElements = document.querySelectorAll('.animate');
animateElements.forEach((el) => observer.observe(el));

const observer2 = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate__fadeIn');
        } else {
            //entry.target.classList.remove('animate__fadeIn');
        }
    });
});

const animateElements2 = document.querySelectorAll('.animateFade');
animateElements2.forEach((el) => observer2.observe(el)); // Use observer2 here


const observer3 = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate__fadeInRight');
        } else {
            //entry.target.classList.remove('animate__fadeInRight');
        }
    });
});

const animateElements3 = document.querySelectorAll('.animateRight');
animateElements3.forEach((el) => observer3.observe(el)); // Use observer2 here





new TypeIt("#welcometext", {
    strings: "iliyandala central is one of the first sports nap national schools in sri lanka established on 1887 (135 years ago) by Mampe Saranapala Thero who is the founder of our school. Today our school has about 4000 students with about 200 teachers studies through both Sinhala and English medium. Mr. D. P. Udawaththage is the principal in present.The school colors are Dark blue, gold, and maroon.",
    speed: 10,
    waitUntilVisible: true,
}).go();




window.addEventListener('scroll', function(){
    //let scrollValue = window.scrollY;
    //let scaleFactor = Math.max(1, 0.5 + scrollValue /600);
    //document.getElementById("scrollValue").innerHTML = scrollValue;
    //document.getElementById("section1").style.transform = 'scale(' + scaleFactor + ')';

    // /document.getElementById("flag").style.transform = 'scale(' + scaleFactor + ')';
    //document.getElementById("flag").style.top = scrollValue/10 + 'px';
});



function navbtn(){
    navBtn = 1;

    if (navBtn = 1){
        document.getElementById("nav-btn").style.display = none;
        document.getElementById("close-btn").style.display = block;
        navBtn = 0;
    } else {
        document.getElementById("nav-btn").style.display = block;
        document.getElementById("close-btn").style.display = none;
        navBtn = 1;

    }
}
